
// A general interface for shape classes.
public interface Shape {
    double getArea();
    double getPerimeter();
}
